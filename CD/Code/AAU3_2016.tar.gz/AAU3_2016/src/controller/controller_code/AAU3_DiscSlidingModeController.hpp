/*
 * AAU3_DiscSlidingModeController.h
 *
 * Code generation for function 'AAU3_DiscSlidingModeController'
 *
 * C source code generated on: Fri Nov 28 10:38:59 2014
 *
 */

#ifndef __AAU3_DISCSLIDINGMODECONTROLLER_H__
#define __AAU3_DISCSLIDINGMODECONTROLLER_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>

#include "rtwtypes.hpp"
#include "AAU3_DiscSlidingModeController_types.hpp"

/* Function Declarations */
extern C_SM_struct_T AAU3_DiscSlidingModeController(real_T C_SM_unusedU0, const real_T C_SM_x[3]);
extern void AAU3_DiscSlidingModeController_initialize(void);
extern void AAU3_DiscSlidingModeController_terminate(void);
#endif
/* End of code generation (AAU3_DiscSlidingModeController.h) */
