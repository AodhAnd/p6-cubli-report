/*
 * AAU3_DiscSlidingModeController_types.h
 *
 * Code generation for function 'AAU3_DiscSlidingModeController'
 *
 * C source code generated on: Fri Nov 28 10:38:59 2014
 *
 */

#ifndef __AAU3_DISCSLIDINGMODECONTROLLER_TYPES_H__
#define __AAU3_DISCSLIDINGMODECONTROLLER_TYPES_H__

/* Include files */
#include "rtwtypes.hpp"
/* Type Definitions */
#ifndef typedef_C_SM_struct_T
#define typedef_C_SM_struct_T
typedef struct
{
    real_T C_SM_U_m;
    real_T C_SM_Brake;
} C_SM_struct_T;
#endif /*typedef_C_SM_struct_T*/

#endif
/* End of code generation (AAU3_DiscSlidingModeController_types.h) */
