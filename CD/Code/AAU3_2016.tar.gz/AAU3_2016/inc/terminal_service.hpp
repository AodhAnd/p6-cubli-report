/*
 * terminal_service.hpp
 *
 *  Created on: 26/08/2014
 *      Author: benjaminkrebs
 */

#ifndef TERMINAL_SERVICE_HPP_
#define TERMINAL_SERVICE_HPP_

/*
 * Jeg t�nker vi s�tter et eller andet message system op s� vi kan starte og stoppe services osv
 *
 */

class TerminalService {
public:
	TerminalService();
	~TerminalService();
private:
};


#endif /* TERMINAL_SERVICE_HPP_ */
