/*
 * AAU3_DiscSlidingModeController_new_types.h
 *
 * Code generation for function 'AAU3_DiscSlidingModeController_new'
 *
 * C source code generated on: Sun Dec 14 11:36:36 2014
 *
 */

#ifndef __AAU3_DISCSLIDINGMODECONTROLLER_NEW_TYPES_H__
#define __AAU3_DISCSLIDINGMODECONTROLLER_NEW_TYPES_H__

/* Include files */
#include "rtwtypes.hpp"

/* Type Definitions */
#ifndef typedef_C_SMC_new_struct_T
#define typedef_C_SMC_new_struct_T
typedef struct
{
    real_T C_SMC_new_U_m;
    real_T C_SMC_new_Brake;
} C_SMC_new_struct_T;
#endif /*typedef_C_SMC_new_struct_T*/

#endif
/* End of code generation (AAU3_DiscSlidingModeController_new_types.h) */
