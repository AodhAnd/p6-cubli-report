/*
 * AAU3_DiscLinObserver_types.h
 *
 * Code generation for function 'AAU3_DiscLinObserver'
 *
 * C source code generated on: Wed Dec 03 13:19:04 2014
 *
 */

#ifndef __AAU3_DISCLINOBSERVER_TYPES_H__
#define __AAU3_DISCLINOBSERVER_TYPES_H__

/* Include files */
#include "rtwtypes.hpp"

/* Type Definitions */
#ifndef typedef_O_Lin_struct_T
#define typedef_O_Lin_struct_T
typedef struct
{
    real_T O_Lin_U_m;
    real_T O_Lin_Brake;
} O_Lin_struct_T;
#endif /*typedef_O_Lin_struct_T*/

#endif
/* End of code generation (AAU3_DiscLinObserver_types.h) */
