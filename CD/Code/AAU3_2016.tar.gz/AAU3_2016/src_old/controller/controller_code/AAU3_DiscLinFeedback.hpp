/*
 * AAU3_DiscLinFeedback.h
 *
 * Code generation for function 'AAU3_DiscLinFeedback'
 *
 * C source code generated on: Fri Nov 21 13:36:15 2014
 *
 */

#ifndef __AAU3_DISCLINFEEDBACK_H__
#define __AAU3_DISCLINFEEDBACK_H__
/* Include files */
#include <stddef.h>
#include <stdlib.h>

#include "rtwtypes.hpp"
#include "AAU3_DiscLinFeedback_types.hpp"

/* Function Declarations */
extern C_Lin_struct_T AAU3_DiscLinFeedback(real_T C_Lin_Ts, const real_T C_Lin_x_hat[3]);
extern void AAU3_DiscLinFeedback_initialize(void);
extern void AAU3_DiscLinFeedback_terminate(void);
#endif
/* End of code generation (AAU3_DiscLinFeedback.h) */
