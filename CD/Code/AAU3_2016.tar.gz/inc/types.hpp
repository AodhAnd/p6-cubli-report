/*
 * types.hpp
 *
 *  Created on: 25/08/2014
 *      Author: benjaminkrebs
 */

#ifndef TYPES_HPP_
#define TYPES_HPP_

typedef unsigned char U8;
typedef unsigned short U16;

#endif /* TYPES_HPP_ */
