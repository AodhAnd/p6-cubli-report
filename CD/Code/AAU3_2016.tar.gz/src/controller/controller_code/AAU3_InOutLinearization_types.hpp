/*
 * AAU3_InOutLinearization_types.h
 *
 * Code generation for function 'AAU3_InOutLinearization'
 *
 * C source code generated on: Tue Dec 02 16:07:14 2014
 *
 */

#ifndef __AAU3_INOUTLINEARIZATION_TYPES_H__
#define __AAU3_INOUTLINEARIZATION_TYPES_H__

/* Include files */
#include "rtwtypes.hpp"

/* Type Definitions */
#ifndef typedef_C_InOut_struct_T
#define typedef_C_InOut_struct_T
typedef struct
{
    real_T C_InOut_U_m;
    real_T C_InOut_Brake;
} C_InOut_struct_T;
#endif /*typedef_C_InOut_struct_T*/

#endif
/* End of code generation (AAU3_InOutLinearization_types.h) */
