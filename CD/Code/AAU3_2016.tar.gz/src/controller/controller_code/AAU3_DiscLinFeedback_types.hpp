/*
 * AAU3_DiscLinFeedback_types.h
 *
 * Code generation for function 'AAU3_DiscLinFeedback'
 *
 * C source code generated on: Fri Nov 21 13:36:15 2014
 *
 */

#ifndef __AAU3_DISCLINFEEDBACK_TYPES_H__
#define __AAU3_DISCLINFEEDBACK_TYPES_H__

/* Include files */
#include "rtwtypes.hpp"

/* Type Definitions */
#ifndef typedef_C_Lin_struct_T
#define typedef_C_Lin_struct_T
typedef struct
{
    real_T C_Lin_U_m;
    real_T C_Lin_Brake;
} C_Lin_struct_T;
#endif /*typedef_C_Lin_struct_T*/

#endif
/* End of code generation (AAU3_DiscLinFeedback_types.h) */
