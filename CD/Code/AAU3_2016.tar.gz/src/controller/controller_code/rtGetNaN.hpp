/*
 * rtGetNaN.h
 *
 * Code generation for function 'DiscreteLinearStateFeedback'
 *
 * C source code generated on: Sun Nov 16 18:26:00 2014
 *
 */

#ifndef __RTGETNAN_H__
#define __RTGETNAN_H__

#include <stddef.h>
#include "rtwtypes.hpp"
#include "rt_nonfinite.hpp"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif
/* End of code generation (rtGetNaN.h) */
