/*
 * AAU3_DiscSlidingModeController_new.h
 *
 * Code generation for function 'AAU3_DiscSlidingModeController_new'
 *
 * C source code generated on: Sun Dec 14 11:36:36 2014
 *
 */

#ifndef __AAU3_DISCSLIDINGMODECONTROLLER_NEW_H__
#define __AAU3_DISCSLIDINGMODECONTROLLER_NEW_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>

#include "rtwtypes.hpp"
#include "AAU3_DiscSlidingModeController_new_types.hpp"

/* Function Declarations */
extern C_SMC_new_struct_T AAU3_DiscSlidingModeController_new(real_T C_SMC_new_unusedU0, const real_T C_SMC_new_x[3]);
extern void AAU3_DiscSlidingModeController_new_initialize(void);
extern void AAU3_DiscSlidingModeController_new_terminate(void);
#endif
/* End of code generation (AAU3_DiscSlidingModeController_new.h) */
