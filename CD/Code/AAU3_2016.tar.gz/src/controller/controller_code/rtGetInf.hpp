/*
 * rtGetInf.h
 *
 * Code generation for function 'DiscreteLinearStateFeedback'
 *
 * C source code generated on: Sun Nov 16 18:26:00 2014
 *
 */

#ifndef __RTGETINF_H__
#define __RTGETINF_H__

#include <stddef.h>
#include "rtwtypes.hpp"
#include "rt_nonfinite.hpp"

extern real_T rtGetInf(void);
extern real32_T rtGetInfF(void);
extern real_T rtGetMinusInf(void);
extern real32_T rtGetMinusInfF(void);

#endif
/* End of code generation (rtGetInf.h) */
